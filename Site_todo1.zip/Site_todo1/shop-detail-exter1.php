<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"><!--<![endif]-->
<head>
    <!-- Basic Page Needs -->
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <title>Todo 1 - Shop</title>

    <meta name="author" content="themesflat.com">

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Bootstrap  -->
    <link rel="stylesheet" type="text/css" href="stylesheets/bootstrap.css" >

    <!-- Theme Style -->
    <link rel="stylesheet" type="text/css" href="stylesheets/style.css">
    <link rel="stylesheet" type="text/css" href="stylesheets/responsive.css">

    <!-- Colors -->
    <link rel="stylesheet" type="text/css" href="stylesheets/colors/color1.css" id="colors">

    <!-- Animation Style -->
    <link rel="stylesheet" type="text/css" href="stylesheets/animate.css">


    <!-- Favicon and touch icons  -->
    <link href="icon/favicon.png" rel="shortcut icon">

    <!--[if lt IE 9]>
        <script src="javascript/html5shiv.js"></script>
        <script src="javascript/respond.min.js"></script>
    <![endif]-->
</head> 
<body class="header_sticky header-style-2 has-menu-extra">
	<!-- Preloader -->
    <div id="loading-overlay">
        <div class="loader"></div>
    </div> 

    <!-- Boxed -->
    <div class="boxed">
    	<div id="site-header-wrap">
            <!-- Header -->
			 <?php include("includes/header.php"); ?>
            <!-- /header -->
        </div><!-- /.site-header-wrap -->

    	<!-- Page title -->
    	<div class="page-title parallax parallax1">
    		<div class="container">
    			<div class="row">
    				<div class="col-md-12">
    					<div class="page-title-heading">
    						<h1 class="title">Prodcutos</h1>
    					</div><!-- /.page-title-heading -->
    				
    				</div><!-- /.col-md-12 -->
    			</div><!-- /.row -->
    		</div><!-- /.container -->
    	</div><!-- /.page-title -->

    	<section class="flat-row main-shop shop-detail style-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                    	<div class="wrap-flexslider clearfix">
                    		<div class="inner padding-top-5">
                    			<div class="flexslider style-2 has-relative">
		                    		<ul class="slides">
		                                <li data-thumb="images/shop/sh-detail/thumb-detail-05.jpg">
		                                    <img src="images/shop/sh-detail/detail-02.jpg" alt="Image">
                                            <div class="flat-icon style-1">
                                                <a href="images/shop/sh-detail/detail-02.jpg" class="zoom-popup"><span class="fa fa-search-plus"></span></a>
                                            </div>
		                                </li>
		                                <li data-thumb="images/shop/sh-detail/thumb-detail-06.jpg">
		                                    <img src="images/shop/sh-detail/detail-04.jpg" alt="Image">
                                            <div class="flat-icon style-1">
                                                <a href="images/shop/sh-detail/detail-02.jpg" class="zoom-popup"><span class="fa fa-search-plus"></span></a>
                                            </div>
		                                </li>
		                                <li data-thumb="images/shop/sh-detail/thumb-detail-07.jpg">
		                                    <img src="images/shop/sh-detail/detail-03.jpg" alt="Image">
                                            <div class="flat-icon style-1">
                                                <a href="images/shop/sh-detail/detail-02.jpg" class="zoom-popup"><span class="fa fa-search-plus"></span></a>
                                            </div>
		                                </li>
		                                <li data-thumb="images/shop/sh-detail/thumb-detail-08.jpg">
		                                    <img src="images/shop/sh-detail/detail-01.jpg" alt="Image">
                                            <div class="flat-icon style-1">
                                                <a href="images/shop/sh-detail/detail-02.jpg" class="zoom-popup"><span class="fa fa-search-plus"></span></a>
                                            </div>
		                                </li>
                                        <li data-thumb="images/shop/sh-detail/thumb-detail-09.jpg">
                                            <img src="images/shop/sh-detail/detail-02.jpg" alt="Image">
                                            <div class="flat-icon style-1">
                                                <a href="images/shop/sh-detail/detail-02.jpg" class="zoom-popup"><span class="fa fa-search-plus"></span></a>
                                            </div>
                                        </li>
		                            </ul>                           
		                        </div><!-- /.flexslider -->
                    		</div>
                    	</div>		                        
                    </div><!-- /.col-md-6 -->

                    <div class="col-md-6">
                        <div class="divider h0"></div>
                        <div class="product-detail clearfix">
                        	<div class="inner">
                        		<div class="content-detail">
                        			<h2 class="product-title">Marvel T-Shirt</h2>
                        			<div class="flat-star style-1">
                        				<i class="fa fa-star"></i>
                        				<i class="fa fa-star"></i>
                        				<i class="fa fa-star"></i>
                        				<i class="fa fa-star-half-o"></i>
                        				<i class="fa fa-star-half-o"></i>
                        				<span>(1)</span>
                        			</div>
                        			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea com- modo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.Contrary to popular belief, Lorem Ipsum is not simply random text. </p> 
                        			<div class="price">
                        				
                        				<ins><span class="amount">$24</span></ins>
                        			</div>                        			
                        			<div class="product-quantity margin-top-49">                        				
                        				<div class="add-to-cart no-margin">
                        					<a href="car.php">Comprar</a>
                        				</div>
                        				<div class="box-like margin-left-3">
                        					<a href="car.php" class="like"><i class="fa fa-heart-o"></i></a>
                        				</div>
                        			</div>
                        		
                        		
                        		</div>
                        	</div>
                        </div><!-- /.product-detail -->
                    </div>
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.flat-row -->

        <!-- /.shop-detail-content -->

        

		<?php include("includes/footer.php"); ?>

		<!-- Footer -->
		<!-- /.footer -->

		

		<!-- Go Top -->
	    <a class="go-top">
	        <i class="fa fa-chevron-up"></i>
	    </a>  

    </div>

	<!-- Javascript -->
	
	 <?php include("includes/scripts.php"); ?> 
</body> 
</html>                               