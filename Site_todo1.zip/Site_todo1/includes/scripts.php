    <script src="javascript/jquery.min.js"></script>
    <script src="javascript/tether.min.js"></script>
    <script src="javascript/bootstrap.min.js"></script> 
    <script src="javascript/jquery.easing.js"></script>    
    <script src="javascript/parallax.js"></script>
    <script src="javascript/jquery-waypoints.js"></script>
    <script src="javascript/jquery-countTo.js"></script>
    <script src="javascript/jquery.countdown.js"></script>
    <script src="javascript/jquery.flexslider-min.js"></script>
    <script src="javascript/images-loaded.js"></script>
    <script src="javascript/jquery.isotope.min.js"></script>
    <script src="javascript/magnific.popup.min.js"></script>
    <script src="javascript/jquery.hoverdir.js"></script>
    <script src="javascript/owl.carousel.min.js"></script>
    <script src="javascript/equalize.min.js"></script>
    <script src="javascript/gmap3.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAIEU6OT3xqCksCetQeNLIPps6-AYrhq-s&region=GB"></script>
    <script src="javascript/jquery-ui.js"></script>
    
    <script src="javascript/jquery.cookie.js"></script>
    <script src="javascript/main.js"></script>

    <!-- Revolution Slider -->
    <script src="rev-slider/js/jquery.themepunch.tools.min.js"></script>
    <script src="rev-slider/js/jquery.themepunch.revolution.min.js"></script>
    <script src="javascript/rev-slider.js"></script>
    <!-- Load Extensions only on Local File Systems ! The following part can be removed on Server for On Demand Loading -->  
    <script src="rev-slider/js/extensions/revolution.extension.actions.min.js"></script>
    <script src="rev-slider/js/extensions/revolution.extension.carousel.min.js"></script>
    <script src="rev-slider/js/extensions/revolution.extension.kenburn.min.js"></script>
    <script src="rev-slider/js/extensions/revolution.extension.layeranimation.min.js"></script>
    <script src="rev-slider/js/extensions/revolution.extension.migration.min.js"></script>
    <script src="rev-slider/js/extensions/revolution.extension.navigation.min.js"></script>
    <script src="rev-slider/js/extensions/revolution.extension.parallax.min.js"></script>
    <script src="rev-slider/js/extensions/revolution.extension.slideanims.min.js"></script>
    <script src="rev-slider/js/extensions/revolution.extension.video.min.js"></script>