<header id="header" class="header header-container clearfix">
                <div class="container clearfix" id="site-header-inner">
                    <div id="logo" class="logo float-left">
                        <a href="" title="logo">
                            <img src="images/logo.jpg" alt="image" width="107" height="24" data-retina="images/logo.jpg" data-width="107" data-height="24">
                        </a>
                    </div><!-- /.logo -->
                    <div class="mobile-button"><span></span></div>
                    <ul class="menu-extra">
                        <li class="box-search">
                            <a class="icon_search header-search-icon" href="#"></a>
                            <form role="search" method="get" class="header-search-form" action="#">
                                <input type="text" value="" name="s" class="header-search-field" placeholder="Search...">
                                <button type="submit" class="header-search-submit" title="Search">Search</button>
                            </form>
                        </li>
                        <li class="box-login">
                            <a class="icon_login" href="#"></a>
                        </li>
                        <li class="box-cart nav-top-cart-wrapper">
                            <a class="icon_cart nav-cart-trigger active" href="#"><span>3</span></a>
                            <div class="nav-shop-cart">
                                <div class="widget_shopping_cart_content">
                                    <div class="woocommerce-min-cart-wrap">
                                        <ul class="woocommerce-mini-cart cart_list product_list_widget ">
                                            <li class="woocommerce-mini-cart-item mini_cart_item">
                                                <span>No Items in Shopping Cart</span>
                                            </li>
                                        </ul>
                                    </div><!-- /.widget_shopping_cart_content -->
                                </div>
                            </div><!-- /.nav-shop-cart -->
                        </li>
                    </ul><!-- /.menu-extra -->
                    <div class="nav-wrap">x
                        <nav id="mainnav" class="mainnav">
                            <ul class="menu">
                              <li class="active">
                                    <a href="index.php">HOME</a>
                                    
                              </li>
								 <li>
                                    <a href="nosotros.php">NOSOTROS</a>
                               
                                </li>
                                <li>
                                    <a href="productos.php">PRODUCTOS</a>
                               
                                </li>
                              
                             
                              <li >
                                    <a href="contacto.php">CONTACTO</a>
                                   
                              </li>
                            </ul>
                        </nav><!-- /.mainnav -->
                    </div><!-- /.nav-wrap -->
                </div><!-- /.container-fluid -->
            </header>