	<section class="flat-row mail-chimp">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="text">
							<h3>Newsletter</h3>
						</div>
					</div>
					<div class="col-md-8">
						<div class="subscribe clearfix">
							<form action="#" method="post" accept-charset="utf-8" id="subscribe-form">
								<div class="subscribe-content">
									<div class="input">
										<input type="email" name="subscribe-email" placeholder="Your Email">
									</div>
									<div class="button">
										<button type="button">SUBCRIBE</button>
									</div>
								</div>
							</form>
							<ul class="flat-social">
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-google"></i></a></li>
							
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
							</ul><!-- /.flat-social -->
						</div><!-- /.subscribe -->
					</div>
				</div>
			</div>
		</section><!-- /.mail-chimp -->

		<!-- Footer -->
		<!-- /.footer -->

		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<p class="copyright text-center">Copyright @2022 <a href="#">Todo 1 Shop</a></p>
					</div>
				</div>
			</div>
		</div>