<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"><!--<![endif]-->
<head>
    <!-- Basic Page Needs -->
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
   <title>Todo 1 - SHop</title>

    <meta name="author" content="themesflat.com">

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Bootstrap  -->
    <link rel="stylesheet" type="text/css" href="stylesheets/bootstrap.css" >

    <!-- Theme Style -->
    <link rel="stylesheet" type="text/css" href="stylesheets/style.css">
    <link rel="stylesheet" type="text/css" href="stylesheets/responsive.css">

    <!-- Colors -->
    <link rel="stylesheet" type="text/css" href="stylesheets/colors/color1.css" id="colors">

    <!-- Animation Style -->
    <link rel="stylesheet" type="text/css" href="stylesheets/animate.css">


    <!-- Favicon and touch icons  -->
    <link href="icon/favicon.png" rel="shortcut icon">

    <!--[if lt IE 9]>
        <script src="javascript/html5shiv.js"></script>
        <script src="javascript/respond.min.js"></script>
    <![endif]-->
</head> 
<body class="header_sticky header-style-2 has-menu-extra">
	<!-- Preloader -->
    <div id="loading-overlay">
        <div class="loader"></div>
    </div> 

    <!-- Boxed -->
    <div class="boxed">
    	<div id="site-header-wrap">
            <!-- Header -->
            <?php include("includes/header.php"); ?>
			<!-- /header -->
        </div><!-- /.site-header-wrap -->

    	<!-- Page title -->
    	<div class="page-title parallax parallax1">
    		<div class="container">
    			<div class="row">
    				<div class="col-md-12">
    					<div class="page-title-heading">
    						<h1 class="title">Productos</h1>
    					</div><!-- /.page-title-heading -->
    					
    				</div><!-- /.col-md-12 -->
    			</div><!-- /.row -->
    		</div><!-- /.container -->
    	</div><!-- /.page-title -->

    	<section class="flat-row main-shop shop-4col">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="filter-shop bottom_68 clearfix">
                            <p class="showing-product">
                               
                            </p>
                            <ul class="flat-filter-search">
                                <li>
                                    <a href="#" class="show-filter">Filters</a>
                                </li>
                                <li class="search-product"><a href="#" >Search</a></li>
                            </ul>
                        </div><!-- /.filte-shop -->
                        <div class="box-filter slidebar-shop clearfix">
                            <div class="btn-close"><a href="#"><i class="fa fa-times"></i></a></div>
                            <div class="widget widget-sort-by">
                                <h5 class="widget-title">
                                    Sort By
                                </h5>
                                <ul>
                                    <li><a href="#" class="active">Default</a></li>
                                    <li><a href="#">Popularity</a></li>
                                    <li><a href="#">Average rating</a></li>
                                    <li><a href="#">Newness</a></li>
                                    <li><a href="#">Price: low to high</a></li>
                                    <li><a href="#">Price: high to low</a></li>
                                </ul>
                            </div><!-- /.widget-sort-by -->
                            <div class="widget widget-price">
                                <h5 class="widget-title">Price</h5>
                                <ul>
                                    <li><a href="#" class="active">$0.00 - $50.00</a></li>
                                    <li><a href="#">$50.00 - $100.00</a></li>
                                    <li><a href="#">$100.00 - $150.00</a></li>
                                    <li><a href="#">$150.00 - $200.00</a></li>
                                    <li><a href="#">$200.00 - 250.00</a></li>
                                    <li><a href="#">250.00+</a></li>
                                </ul>
                            </div><!-- /.widget -->
                            <div class="widget widget-color">
                                <h5 class="widget-title">
                                   Colors
                                </h5>
                                <ul class="flat-color-list icon-left">
                                    <li><a href="#" class="yellow"></a><span>Yellow</span></li>
                                    <li><a href="#" class="pink"> </a><span>White</span></li>
                                    <li><a href="#" class="red active"></a><span>Red</span> </li>
                                    <li><a href="#" class="black"></a><span>Black</span></li>
                                    <li><a href="#" class="blue"></a><span>Green</span></li>
                                    <li><a href="#" class="khaki"></a><span>Orange</span></li>
                                </ul>
                            </div><!-- /.widget-color -->
                            <div class="widget widget-size">
                                <h5 class="widget-title">Size</h5>
                                <ul>
                                    <li><a href="#">L</a></li>
                                    <li><a href="#">M</a></li>
                                    <li><a href="#">S</a></li>
                                    <li><a href="#">XL</a></li>
                                    <li><a href="#">XXL</a></li>
                                    <li><a href="#">Over Size</a></li>
                                </ul>
                            </div><!-- /.widget -->
                            <div class="widget widget_tag">
                                <h5 class="widget-title">
                                    Tags
                                </h5>
                                <div class="tag-list">
                                    <a href="#">All products</a>
                                    <a href="#" class="active">Bags</a>
                                    <a href="#">Chair</a>
                                    <a href="#">Decoration</a>
                                    <a href="#">Fashion</a> 
                                    <a href="#">Tie</a>
                                    <a href="#">Furniture</a>
                                    <a href="#">Accesories</a> 
                                </div>
                            </div><!-- /.widget -->
                        </div><!-- /.box-filter -->
                        <div class="shop-search clearfix">            
                            <form role="search" method="get" class="search-form" action="#">
                                <label>                                    
                                    <input type="search" class="search-field" placeholder="Searching …" value="" name="s">
                                </label>
                            </form>       
                        </div><!-- /.top-serach -->
                        <div class="product-content product-fourcolumn clearfix">
                            <ul class="product style2">
                                <li class="product-item">
                                    <div class="product-thumb clearfix">
                                        <a href="shop-detail-exter1.php">
                                            <img src="images/shop/sh-4/13.jpg" alt="image">
                                        </a>
                                    </div>
                                    <div class="product-info clearfix">
                                        <span class="product-title">Sweter</span>
                                        <div class="price">
                                            <ins>
                                                <span class="amount">$19.00</span>
                                            </ins>
                                        </div>
                                     
                                    </div>
                                    <div class="add-to-cart text-center">
                                        <a href="shop-detail-exter1.php">COMPRAR</a>
                                    </div>
                                    <a href="#" class="like"><i class="fa fa-heart-o"></i></a>
                                </li>
                                <li class="product-item">
                                    <div class="product-thumb clearfix">
                                        <a href="shop-detail-exter1.php">
                                            <img src="images/shop/sh-4/14.jpg" alt="image">
                                        </a>
                                        <span class="new">New</span>
                                    </div>
                                    <div class="product-info clearfix">
                                        <span class="product-title">Funko</span>
                                        <div class="price">
                                            <ins>
                                                <span class="amount">$10.00</span>
                                            </ins>
                                        </div>
                                    </div>
                                    <div class="add-to-cart text-center">
                                        <a href="shop-detail-exter1.php">COMPRAR</a>
                                    </div>
                                    <a href="#" class="like"><i class="fa fa-heart-o"></i></a>
                                </li>
                                <li class="product-item">
                                    <div class="product-thumb clearfix">
                                        <a href="shop-detail-exter1.php" class="product-thumb">
                                            <img src="images/shop/sh-4/15.jpg" alt="image">
                                        </a>
                                    </div>
                                    <div class="product-info clearfix">
                                        <span class="product-title">Vaso</span>
                                        <div class="price">
                                            <ins>
                                                <span class="amount">$20.00</span>
                                            </ins>
                                        </div>
                                    </div>
                                    <div class="add-to-cart text-center">
                                        <a href="shop-detail-exter1.php">COMPRAR</a>
                                    </div>
                                    <a href="#" class="like"><i class="fa fa-heart-o"></i></a>
                                </li>
                                <li class="product-item">
                                    <div class="product-thumb clearfix">
                                        <a href="shop-detail-exter1.php" class="product-thumb">
                                            <img src="images/shop/sh-4/16.jpg" alt="image">
                                        </a>
                                       
                                    </div>
                                    <div class="product-info clearfix">
                                        <span class="product-title">T Shirt</span>
                                        <div class="price">
                                           
                                            <ins>
                                                <span class="amount">$60.00</span>
                                            </ins>
                                        </div>
                                     
                                    </div>
                                    <div class="add-to-cart text-center">
                                        <a href="shop-detail-exter1.php">COMPRAR</a>
                                    </div>
                                    <a href="#" class="like"><i class="fa fa-heart-o"></i></a>
                                </li>
                              
                          
                            
                          
                               
                              
                            </ul><!-- /.product -->
                        </div><!-- /.product-content -->
                        <div class="product-pagination text-center margin-top-11 clearfix">
                            <ul class="flat-pagination">
                                <li class="prev">
                                    <a href="#"><i class="fa fa-angle-left"></i></a>
                                </li>
                                <li><a href="#">1</a></li>
                                <li class="active"><a href="#" title="">2</a></li>
                                <li><a href="#">3</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i></a></li>
                            </ul><!-- /.flat-pagination -->
                        </div>
                    </div><!-- /.col-md-12 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.flat-row -->

		<?php include("includes/footer.php"); ?>

		<!-- Footer -->
		<!-- /.footer -->

		

		<!-- Go Top -->
	    <a class="go-top">
	        <i class="fa fa-chevron-up"></i>
	    </a>  

    </div>

	<!-- Javascript -->
	
	 <?php include("includes/scripts.php"); ?> 
</body> 
</html>                               