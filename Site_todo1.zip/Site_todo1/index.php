<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"><!--<![endif]-->
<head>
    <!-- Basic Page Needs -->
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <title>Todo 1 - SHop</title>

    <meta name="author" content="themesflat.com">

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Bootstrap  -->
    <link rel="stylesheet" type="text/css" href="stylesheets/bootstrap.css" >

    <!-- Theme Style -->
    <link rel="stylesheet" type="text/css" href="stylesheets/style.css">
    <link rel="stylesheet" type="text/css" href="stylesheets/responsive.css">

    <!-- Colors -->
    <link rel="stylesheet" type="text/css" href="stylesheets/colors/color1.css" id="colors">

    <!-- Animation Style -->
    <link rel="stylesheet" type="text/css" href="stylesheets/animate.css">


    <!-- Favicon and touch icons  -->
    <link href="icon/favicon.png" rel="shortcut icon">

    <!--[if lt IE 9]>
        <script src="javascript/html5shiv.js"></script>
        <script src="javascript/respond.min.js"></script>
    <![endif]-->
</head> 
<body class="header_sticky header-style-1 has-menu-extra">
	<!-- Preloader -->
    <div id="loading-overlay">
        <div class="loader"></div>
    </div>

    <!-- Boxed -->
    <div class="boxed">
        <div id="site-header-wrap">
            <!-- Header -->
			
			  <?php include("includes/header.php"); ?>
			
			
            <!-- /header -->
        </div><!-- /#site-header-wrap -->

    	<!-- SLIDER -->
        <div class="rev_slider_wrapper fullwidthbanner-container">
            <div id="rev-slider1" class="rev_slider fullwidthabanner">
                <ul>                   
                    <!-- Slide 1 -->
                    <li data-transition="random">
                        <!-- Main Image -->
                        <img src="images/slider/slider-bg-5.jpg" alt="" data-bgposition="center center" data-no-retina>
                       
                        <!-- Layers -->
                        <div class="tp-caption tp-resizeme text-white font-weight-300"
                            data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                            data-y="['middle','middle','middle','middle']" data-voffset="['-93','-93','-93','-93']"
                            data-fontsize="['24','24','24','18']"
                            data-lineheight="['72','72','72','36']"
                            data-width="full"
                            data-height="none"
                            data-whitespace="normal"
                            data-transform_idle="o:1;"
                            data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                            data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                            data-mask_in="x:0px;y:[100%];" 
                            data-mask_out="x:inherit;y:inherit;" 
                            data-start="700" 
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on">
                           
                        </div>

                        <div class="tp-caption tp-resizeme text-white font-weight-500"
                            data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                            data-y="['middle','middle','middle','middle']" data-voffset="['-42','-42','-42','-42']"
                            data-fontsize="['52','52','52','40']"
                            data-lineheight="['60','60','60','40']"
                            data-width="full"
                            data-height="none"
                            data-whitespace="normal"
                            data-transform_idle="o:1;"
                            data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                            data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                            data-mask_in="x:0px;y:[100%];" 
                            data-mask_out="x:inherit;y:inherit;" 
                            data-start="1000" 
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on">
                            Nueva colección
                        </div>

                        <div class="tp-caption tp-resizeme text-white font-weight-400 "
                            data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                            data-y="['middle','middle','middle','middle']" data-voffset="['12','12','12','12']"
                            data-fontsize="['18','18','18','16']"
                            data-lineheight="['72','72','72','38']"
                            data-width="full"
                            data-height="none"
                            data-whitespace="normal"
                            data-transform_idle="o:1;"
                            data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                            data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                            data-mask_in="x:0px;y:[100%];" 
                            data-mask_out="x:inherit;y:inherit;" 
                            data-start="1000" 
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on">
                            Descuento 30%
                        </div>

                        <div class="tp-caption"
                            data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                            data-y="['middle','middle','middle','middle']" data-voffset="['80','80','80','80']"
                            data-width="full"
                            data-height="none"
                            data-whitespace="normal"
                            data-transform_idle="o:1;"
                            data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                            data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                            data-mask_in="x:0px;y:[100%];" 
                            data-mask_out="x:inherit;y:inherit;" 
                            data-start="1000" 
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on">
                            <a href="#" class="themesflat-button has-padding-36 bg-accent has-shadow"><span>Comprar</span></a>
                        </div>
                    </li>
                    <!-- /End Slide 1 -->
                    
                    <!-- Slide 2 -->
                    <li data-transition="random">
                        <!-- Main Image -->
                        <img src="images/slider/slider-bg-1.jpg" alt="" data-bgposition="center center" data-no-retina>
                       
                        <!-- Layers -->
                         <div class="tp-caption tp-resizeme text-white font-weight-300"
                            data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                            data-y="['middle','middle','middle','middle']" data-voffset="['-93','-93','-93','-93']"
                            data-fontsize="['24','24','24','18']"
                            data-lineheight="['72','72','72','36']"
                            data-width="full"
                            data-height="none"
                            data-whitespace="normal"
                            data-transform_idle="o:1;"
                            data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                            data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                            data-mask_in="x:0px;y:[100%];" 
                            data-mask_out="x:inherit;y:inherit;" 
                            data-start="700" 
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on">
                            
                        </div>

                        <div class="tp-caption tp-resizeme text-white font-weight-500"
                            data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                            data-y="['middle','middle','middle','middle']" data-voffset="['-42','-42','-42','-42']"
                            data-fontsize="['52','52','52','40']"
                            data-lineheight="['60','60','60','40']"
                            data-width="full"
                            data-height="none"
                            data-whitespace="normal"
                            data-transform_idle="o:1;"
                            data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                            data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                            data-mask_in="x:0px;y:[100%];" 
                            data-mask_out="x:inherit;y:inherit;" 
                            data-start="1000" 
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on">
                            Nueva colección
                        </div>

                        <div class="tp-caption tp-resizeme text-white font-weight-400 "
                            data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                            data-y="['middle','middle','middle','middle']" data-voffset="['12','12','12','12']"
                            data-fontsize="['18','18','18','16']"
                            data-lineheight="['72','72','72','38']"
                            data-width="full"
                            data-height="none"
                            data-whitespace="normal"
                            data-transform_idle="o:1;"
                            data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                            data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                            data-mask_in="x:0px;y:[100%];" 
                            data-mask_out="x:inherit;y:inherit;" 
                            data-start="1000" 
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on">
                            Descuento 30%
                        </div>

                        <div class="tp-caption"
                            data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                            data-y="['middle','middle','middle','middle']" data-voffset="['80','80','80','80']"
                            data-width="full"
                            data-height="none"
                            data-whitespace="normal"
                            data-transform_idle="o:1;"
                            data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                            data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                            data-mask_in="x:0px;y:[100%];" 
                            data-mask_out="x:inherit;y:inherit;" 
                            data-start="1000" 
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on">
                            <a href="#" class="themesflat-button has-padding-36 bg-accent has-shadow"><span>Comprar</span></a>
                        </div>
                    </li>
                    <!-- /End Slide 2 -->
                </ul>
            </div> 
        </div>
        <!-- END SLIDER -->

        <!-- IMAGE BOX -->
        
        <!-- END IMAGE BOX -->

        <!-- PRODUCT NEW -->
        <section class="flat-row row-product-new">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title-section margin-bottom-52">
                            <h2 class="title">
                                Productos
                            </h2>
                        </div>
                        <div class="product-content product-fourcolumn clearfix">
                            <ul class="product style2 clearfix">
                                <li class="product-item">
                                    <div class="product-thumb clearfix">
                                        <a href="#" class="product-thumb">
                                            <img src="images/shop/sh-4/13.jpg" alt="image">
                                        </a>
                                        <span class="new">New</span>
                                    </div>
                                    <div class="product-info text-center clearfix">
                                        <span class="product-title">Sweter</span>
                                        <div class="price">
                                            <ins>
                                                <span class="amount">$100</span>
                                            </ins>
                                        </div>
                                    
                                    </div>
                                    <div class="add-to-cart text-center">
                                        <a href="shop-detail-exter1.html">COMPRAR</a>
                                    </div>
                                    <a href="#" class="like"><i class="fa fa-heart-o"></i></a>
                                </li>

                                <li class="product-item">
                                    <div class="product-thumb clearfix">
                                        <a href="#" class="product-thumb">
                                            <img src="images/shop/sh-4/14.jpg" alt="image">
                                        </a>
                                        
                                    </div>
                                    <div class="product-info clearfix">
                                        <span class="product-title">Funko</span>
                                        <div class="price">
                                            <ins>
                                                <span class="amount">$100</span>
                                            </ins>
                                        </div>
                                      
                                    </div>
                                    <div class="add-to-cart text-center">
                                        <a href="shop-detail-exter1.html">COMPRAR</a>
                                    </div>
                                    <a href="#" class="like"><i class="fa fa-heart-o"></i></a>
                                </li>
                                <li class="product-item">
                                    <div class="product-thumb clearfix">
                                        <a href="#" class="product-thumb">
                                            <img src="images/shop/sh-4/15.jpg" alt="image">
                                        </a>
                                     
                                    </div>
                                    <div class="product-info clearfix">
                                        <span class="product-title">Vaso</span>
                                        <div class="price">
                                           
                                            <ins>
                                                <span class="amount">$100</span>
                                            </ins>
                                        </div>
                                    </div>
                                    <div class="add-to-cart text-center">
                                        <a href="shop-detail-exter1.html">COMPRAR</a>
                                    </div>
                                    <a href="#" class="like"><i class="fa fa-heart-o"></i></a>
                                </li>
                                <li class="product-item">
                                    <div class="product-thumb clearfix">
                                        <a href="#" class="product-thumb">
                                            <img src="images/shop/sh-4/16.jpg" alt="image">
                                        </a>
                                    </div>
                                    <div class="product-info clearfix">
                                        <span class="product-title">T Shirt</span>
                                        <div class="price">
                                            <ins>
                                                <span class="amount">$100</span>
                                            </ins>
                                        </div>
                                    
                                    </div>
                                    <div class="add-to-cart text-center">
                                        <a href="shop-detail-exter1.html">COMPRAR</a>
                                    </div>
                                    <a href="#" class="like"><i class="fa fa-heart-o"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section>
        <!-- END PRODUCT NEW -->

        <!-- ANIMATION BOX -->
        <section class="flat-row row-animation-box bg-section row-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                                         
                    </div>
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section>
        <!-- END ANIMATION BOX -->

        <!-- PRODUCT -->
        
        <!-- END PRODUCT -->

        <!-- ICON BOX -->
        
        <!-- END ICON BOX -->

        <!-- NEW LATEST -->
        
        <!-- END NEW LATEST -->

	
		 <?php include("includes/footer.php"); ?>
		
		

		<!-- Go Top -->
	    <a class="go-top">
	        <i class="fa fa-chevron-up"></i>
	    </a>  

    </div>

	<!-- Javascript -->
	
	 <?php include("includes/scripts.php"); ?> 
	

</body> 
</html>                               