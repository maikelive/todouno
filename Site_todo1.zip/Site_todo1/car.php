<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"><!--<![endif]-->
<head>
    <!-- Basic Page Needs -->
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <title>Todo 1 Shop</title>

    <meta name="author" content="themesflat.com">

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Bootstrap  -->
    <link rel="stylesheet" type="text/css" href="stylesheets/bootstrap.css" >

    <!-- Theme Style -->
    <link rel="stylesheet" type="text/css" href="stylesheets/style.css">
    <link rel="stylesheet" type="text/css" href="stylesheets/responsive.css"> 

    <!-- Colors -->
    <link rel="stylesheet" type="text/css" href="stylesheets/colors/color1.css" id="colors">

    <!-- Animation Style -->
    <link rel="stylesheet" type="text/css" href="stylesheets/animate.css">


    <!-- Favicon and touch icons  -->
    <link href="icon/favicon.png" rel="shortcut icon">

    <!--[if lt IE 9]>
        <script src="javascript/html5shiv.js"></script>
        <script src="javascript/respond.min.js"></script>
    <![endif]-->
</head> 
<body class="header_sticky header-style-2 has-menu-extra">
	<!-- Preloader -->
    <div id="loading-overlay">
        <div class="loader"></div>
    </div> 

    <!-- Boxed -->
    <div class="boxed">
    	<div id="site-header-wrap">
            <!-- Header -->
             <?php include("includes/header.php"); ?>
			<!-- /header -->
        </div><!-- /.site-header-wrap -->

    	<!-- Page title -->
    	<div class="page-title parallax parallax1">
    		<div class="container">
    			<div class="row">
    				<div class="col-md-12">
    					<div class="page-title-heading">
    						<h1 class="title">FAQ</h1>
    					</div><!-- /.page-title-heading -->
    					<div class="breadcrumbs">
    						<ul>
    							<li><a href="index.html">Home</a></li>
    							<li><a href="coming-soon.html">Page</a></li>
                                <li><a href="faqs.html">Faq</a></li>
    						</ul>
    					</div><!-- /.breadcrumbs -->
    				</div><!-- /.col-md-12 -->
    			</div><!-- /.row -->
    		</div><!-- /.container -->
    	</div><!-- /.page-title -->

    	<section class="flat-row">
            <div class="container">
                <div class="row">
                    <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">FOTO</th>
      <th scope="col">NOMBRE PRODCUTO</th>
      <th scope="col">UNIDAD</th>
      <th scope="col">TOTAL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
     <td class="product-thumbnail">
        <a href="#"><img src="images/shop/sh-detail/thumb-detail-05.jpg" alt=""></a>
    </td>
      <td>Marvel</td>
      <td>1</td>
      <td>$50</td>
    </tr>
	  
    <tr>
      <td class="product-thumbnail">
        <a href="#"><img src="images/shop/sh-detail/thumb-detail-06.jpg" alt=""></a>
    </td>
     <td>Marvel</td>
      <td>1</td>
       <td>$50</td>
    </tr>
   <tr>
      <td class="product-thumbnail">
        <a href="#"><img src="images/shop/sh-detail/thumb-detail-07.jpg" alt=""></a>
    </td>
     <td>Marvel</td>
      <td>1</td>
       <td>$50</td>
    </tr>
  </tbody>
</table>
<div class="col-md-12">
                        <div class="divider h0"></div>
                        <div class="product-detail clearfix">
                        	<div class="inner">
                        		<div class="content-detail">
                        		
                        		                     			
                        			<div  style="text-align: right"class="product-quantity margin-top-49">                        				
                        				<div class="add-to-cart no-margin">
                        					<a href="#">Pagar</a>
                        				</div>
                        			
                        			</div>
                        		
                        			
                        		</div>
                        	</div>
                        </div><!-- /.product-detail -->
                    </div>
                </div><!-- /.row -->
              
                
                <!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.flat-row --><br>
<br>
<br>
<br>

		
	<?php include("includes/footer.php"); ?>

		<!-- Footer -->
		<!-- /.footer -->

		

		<!-- Go Top -->
	    <a class="go-top">
	        <i class="fa fa-chevron-up"></i>
	    </a>  

    </div>

	<!-- Javascript -->
	
	 <?php include("includes/scripts.php"); ?> 
</body> 
</html>                               